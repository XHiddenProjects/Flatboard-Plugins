<?php
/************* Информация о плагине ОБЯЗАТЕЛЬНА!! ***************/
$lang[$plugin.'name']           = 'Профиль';
$lang[$plugin.'version']        = '2.1';
$lang[$plugin.'update']         = '2021-09-30';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://flatboard.org';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Язык  ***************/
$lang[$plugin.'description']    = 'Разрешить всем пользователям создавать собственный профиль на вашем форуме';

$lang['menu']    				= 'Меню';
$lang[$plugin.'display_menu']   = 'Отображение в меню';
$lang['Profile'] 			    = 'Профиль';
$lang['label_user_psw']			    = 'Введите зашифрованный пароль: <b>Default: true password</b>';
$lang['user_place']             = 'Введите зашифрованный пароль';
$lang['label_username']         = 'Введите собственное имя пользователя (это можно сделать только <b> ОДИН РАЗ </b>, чтобы связаться с администратором форума, чтобы изменить имя пользователя)';
$lang['user_err']               = 'Пароль должен быть зашифрован.';
$lang['img_uplod_label']        = 'Введите изображение:';
$lang['save_profile']           = 'Сохранить';
$lang['loggin']                 = 'Вы должны войти в систему, чтобы использовать профиль';
?>