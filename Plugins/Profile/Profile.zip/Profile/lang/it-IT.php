<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']           = 'Profilo';
$lang[$plugin.'version']        = '1.0';
$lang[$plugin.'update']         = '2021-09-22';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://flatboard.org';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Langue  ***************/
$lang[$plugin.'description']    = 'Consenti a tutti gli utenti di creare un profilo personalizzato sul tuo forum';

$lang['menu']    				= 'Menù';
$lang[$plugin.'display_menu']   = 'Visualizza nel menu';
$lang['Profile'] 			    = 'Profilo';
$lang['label_user']			    = 'Nome utente(nomeutente@digits::<b>ASSICURATI CHE SIA IL TUO NOME UTENTE!</b>';
$lang['user_place']             = 'Inserire username';
$lang['user_err']               = 'Deve essere nomeutente@cifre';
$lang['img_uplod_label']        = 'Inserisci immagine:';
$lang['save_profile']           = 'Salva';
?>