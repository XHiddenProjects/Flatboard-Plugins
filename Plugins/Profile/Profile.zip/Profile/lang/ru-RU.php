<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']           = 'Профиль';
$lang[$plugin.'version']        = '1.0';
$lang[$plugin.'update']         = '2021-09-22';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://flatboard.org';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Langue  ***************/
$lang[$plugin.'description']    = 'Разрешить всем пользователям создавать собственный профиль на вашем форуме';

$lang['menu']    				= 'Меню';
$lang[$plugin.'display_menu']   = 'Отображение в меню';
$lang['Profile'] 			    = 'Профиль';
$lang['label_user']			    = 'Имя пользователя (имя пользователя @ цифры::<b> УБЕДИТЕСЬ, ЧТО СВОЕ ИМЯ ПОЛЬЗОВАТЕЛЯ! </b>';
$lang['user_place']             = 'Введите имя пользователя';
$lang['user_err']               = 'Имя пользователя должно быть@цифр.';
$lang['img_uplod_label']        = 'Введите изображение:';
$lang['save_profile']           = 'Сохранить';
$lang['loggin']                 = 'Вы должны войти в систему, чтобы использовать профиль';
?>