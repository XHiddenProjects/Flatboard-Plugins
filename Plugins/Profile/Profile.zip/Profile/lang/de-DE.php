<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']           = 'Profil';
$lang[$plugin.'version']        = '1.0';
$lang[$plugin.'update']         = '2021-09-22';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://flatboard.org';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Langue  ***************/
$lang[$plugin.'description']    = 'Erlauben Sie allen Benutzern, ein benutzerdefiniertes Profil in Ihrem Forum zu erstellen';

$lang['menu']    				= 'Speisekarte';
$lang[$plugin.'display_menu']   = 'Anzeige im Menü';
$lang['Profile'] 			    = 'Profil';
$lang['label_user']			    = 'Benutzername(username@digits::<b>Stellen Sie sicher, dass es Ihr Benutzername ist!</b>';
$lang['user_place']             = 'Benutzername eingeben';
$lang['user_err']               = 'Muss benutzername@ziffern sein';
$lang['img_uplod_label']        = 'Bild eingeben:';
$lang['save_profile']           = 'Speichern';
?>