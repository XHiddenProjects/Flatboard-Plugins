<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']           = 'Profile';
$lang[$plugin.'version']        = '2.0';
$lang[$plugin.'update']         = '2021-09-22';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://flatboard.org';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Langue  ***************/
$lang[$plugin.'description']    = 'Allow all users to make custom profile on your forum';

$lang['menu']    				= 'Menu';
$lang[$plugin.'display_menu']   = 'Display in menu';
$lang['Profile'] 			    = 'Profile';
$lang['label_user']			    = 'Username(username@digits::<b>MAKE SURE ITS YOUR USERNAME!</b>';
$lang['user_place']             = 'Enter Username';
$lang['user_err']               = 'Must be username@digits';
$lang['img_uplod_label']        = 'Enter Image:';
$lang['save_profile']           = 'Save';
$lang['loggin']                 = 'You must be logged in to use the profile';
?>