<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']           = 'Profil';
$lang[$plugin.'version']        = '1.0';
$lang[$plugin.'update']         = '2021-09-22';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://flatboard.org';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Langue  ***************/
$lang[$plugin.'description']    = 'Autoriser tous les utilisateurs à créer un profil personnalisé sur votre forum';

$lang['menu']    				= 'Menu';
$lang[$plugin.'display_menu']   = 'Affichage dans le menu';
$lang['Profile'] 			    = 'Profil';
$lang['label_user']			    = "Nom d'utilisateur (nom d'utilisateur@chiffres::<b> ASSUREZ-VOUS QUE C'EST VOTRE NOM D'UTILISATEUR !</b>";
$lang['user_place']             = "Saisissez votre nom d'utilisateur";
$lang['user_err']               = "Doit être nom d'utilisateur@chiffres";
$lang['img_uplod_label']        = "Entrez l'image :";
$lang['save_profile']           = 'sauvegarder';
$lang['loggin']                 = 'Vous devez être connecté pour utiliser le profil';
?>