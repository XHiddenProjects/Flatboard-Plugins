<?php
/************* Plugin-Informationen ERFORDERLICH! ***************/
$lang[$plugin.'name']           = 'Spam-Schutz';
$lang[$plugin.'version']        = '1.0.0';
$lang[$plugin.'update']         = '2024-10-11';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Sprache  ***************/
$lang[$plugin.'description']    = 'Verhindert jegliches Kopieren von Themen';
$lang[$plugin.'Measure'] = 'Kopierbereich: <span class="text-info">0 %=Alle nahen Übereinstimmungen - 100 %=Identischer Spam</span>';
?>