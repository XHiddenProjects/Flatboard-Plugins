<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Birthday';
$lang[$plugin.'version']        = '1.0.1';
$lang[$plugin.'update']         = '2023-03-24';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Show users its your special day by making a notification on your birthday!!!';
$lang['invalid_date']           = 'Invalid Date';
$lang['success_date']           = 'Successfully added in your birthday';
$lang['intro_bday']             = '<i class="fa fa-birthday-cake"></i> Happy Birthday to ';
?>