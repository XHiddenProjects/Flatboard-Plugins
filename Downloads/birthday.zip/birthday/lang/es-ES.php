<?php
/************* Información del complemento REQUERIDO! ***************/
$lang[$plugin.'name']           = 'Birthday';
$lang[$plugin.'version']        = '1.0.1';
$lang[$plugin.'update']         = '2023-03-24';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Idioma  ***************/
$lang[$plugin.'description']    = '¡Muestre a los usuarios que es su día especial haciendo una notificación en su cumpleaños!';
$lang['invalid_date']           = 'Fecha invalida';
$lang['success_date']           = 'Añadido exitosamente en tu cumpleaños';
$lang['intro_bday']             = '<i class="fa fa-birthday-cake"></i> Feliz cumpleaños a ';
?>