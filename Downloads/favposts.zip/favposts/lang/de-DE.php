<?php
/************* Plugin-Info ERFORDERLICH! ***************/
$lang[$plugin.'name']           = 'Lieblingsbeiträge';
$lang[$plugin.'version']        = '1.0.0';
$lang[$plugin.'update']         = '2023-06-03';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Sprache  ***************/
$lang[$plugin.'description']    = 'Zeigt Ihre Lieblingsbeiträge automatisch an, indem Sie einen Stern daneben platzieren.';
$lang[$plugin.'favlabel']       = 'Favorit';
?>