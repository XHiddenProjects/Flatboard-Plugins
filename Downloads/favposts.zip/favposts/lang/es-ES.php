<?php
/************* Información del complemento REQUERIDO! ***************/
$lang[$plugin.'name']           = 'Publicaciones favoritas';
$lang[$plugin.'version']        = '1.0.1';
$lang[$plugin.'update']         = '2023-06-05';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Idioma  ***************/
$lang[$plugin.'description']    = 'Muestra automáticamente tus publicaciones favoritas colocando una estrella al lado.';
$lang[$plugin.'favlabel'] = 'Favorito';
$lang[$plugin.'favlabel'] = 'Favorito';
$lang[$plugin.'forum'] = 'Foro';
$lang[$plugin.'user'] = 'Nombre de usuario';
?>