<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'Favorite Posts';
$lang[$plugin.'version']        = '1.0.1';
$lang[$plugin.'update']         = '2023-06-05';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Automatically displays your favorite posts by placing a star next to it.';
$lang[$plugin.'favlabel']       = 'Favorite';
$lang[$plugin.'forum']          = 'Forum';
$lang[$plugin.'user']           = 'Username';
?>