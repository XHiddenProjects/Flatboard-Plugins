<?php
/************* 需要插件信息！ ***************/
$lang[$plugin.'name']           = '最喜欢的帖子';
$lang[$plugin.'version']        = '1.0.0';
$lang[$plugin.'update']         = '2023-06-03';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* 语言  ***************/
$lang[$plugin.'description']    = '通过在旁边放置一个星标来自动显示您最喜欢的帖子。';
$lang[$plugin.'favlabel'] = '最爱';
?>