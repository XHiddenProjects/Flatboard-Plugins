<?php
/************* Informazioni sul plugin OBBLIGATORIE! ***************/
$lang[$plugin.'name']           = 'Post preferiti';
$lang[$plugin.'version']        = '1.0.1';
$lang[$plugin.'update']         = '2023-06-05';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Lingua  ***************/
$lang[$plugin.'description']    = 'Visualizza automaticamente i tuoi post preferiti posizionando una stella accanto ad essi.';
$lang[$plugin.'favlabel'] = 'Preferito';
$lang[$plugin.'favlabel'] = 'Preferito';
$lang[$plugin.'forum'] = 'Forum';
$lang[$plugin.'user'] = 'Nome utente';
?>