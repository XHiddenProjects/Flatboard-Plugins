<?php
/************* Информация о плагине ТРЕБУЕТСЯ! ***************/
$lang[$plugin.'name']           = 'Избранные посты';
$lang[$plugin.'version']        = '1.0.0';
$lang[$plugin.'update']         = '2023-06-03';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Язык  ***************/
$lang[$plugin.'description']    = 'Автоматически отображает ваши любимые сообщения, ставя звездочку рядом с ними.';
$lang[$plugin.'favlabel'] = 'Избранное';
?>