<?php
/************* Informazioni sul plugin OBBLIGATORIE! ***************/
$lang[$plugin.'name']           = 'Lettore della mente';
$lang[$plugin.'version']        = '1.0.0';
$lang[$plugin.'update']         = '2023-06-08';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Lingua  ***************/
$lang[$plugin.'description']    = 'Un`intelligenza artificiale che darà i tuoi consigli in base all`argomento, 
anche il rendering anche un riassunto sull`argomento.';
$lang[$plugin.'sum']            = 'Riepilogo';
$lang[$plugin.'rep']            = 'Risposte';
?>