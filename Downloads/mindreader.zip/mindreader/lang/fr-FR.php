<?php
/************* Informations sur le plugin OBLIGATOIRES ! ***************/
$lang[$plugin.'name']           = 'Lecteur d`esprit';
$lang[$plugin.'version']        = '1.0.0';
$lang[$plugin.'update']         = '2023-06-08';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Langue  ***************/
$lang[$plugin.'description']    = 'Une IA qui donnera vos recommandations en fonction du sujet, rendant également
également un résumé sur le sujet.';
$lang[$plugin.'sum']            = 'Résumé';
$lang[$plugin.'rep']            = 'réponses';
?>