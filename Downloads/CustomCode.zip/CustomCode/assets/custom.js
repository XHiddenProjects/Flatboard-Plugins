setTimeout(function(){
document.querySelector('footer').style.display = "none";
}, 0);
setTimeout(function(){
document.querySelector('small').style.display = "none";
}, 0);
