<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Gravatar';
$lang[$plugin.'version']         = '0.1';
$lang[$plugin.'update']          = '2023-10-19';
$lang[$plugin.'author']          = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']     = 'https://github.com/xhiddenproject';
$lang[$plugin.'author_mail']     = '';
/************* Langue fr ***************/
$lang[$plugin.'description']     = 'Chargez votre gravatar ici !';
$lang['username']                = 'Nom d`utilisateur';
$lang['email']                   = 'E-mail Gravatar';
$lang['size']                    = 'Taille';
$lang['default']                 = 'Défaut';
$lang['dicons']                  = ['blank' => 'blank', 'robohash' => 'robohash', 'wavatar' => 'wavatar', 'monsterid' => 'monsterid', 'identicon' => 'identicon', 'mp' => 'mp', '404' => '404'];
$lang['rating']                  = 'Notation';
?>