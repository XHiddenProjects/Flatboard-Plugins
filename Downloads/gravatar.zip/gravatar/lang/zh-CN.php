<?php
/************* Infos Plugin REQUIS! ***************/
$lang[$plugin.'name']            = 'Gravatar';
$lang[$plugin.'version']         = '0.1';
$lang[$plugin.'update']          = '2023-10-19';
$lang[$plugin.'author']          = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']     = 'https://github.com/xhiddenproject';
$lang[$plugin.'author_mail']     = '';
/************* Langue fr ***************/
$lang[$plugin.'description']     = '在这里加载您的头像！';
$lang['username']                = '用户名';
$lang['email']                   = '头像电子邮件';
$lang['size']                    = '尺寸';
$lang['default']                 = '默认';
$lang['dicons']                  = ['blank' => 'blank', 'robohash' => 'robohash', 'wavatar' => 'wavatar', 'monsterid' => 'monsterid', 'identicon' => 'identicon', 'mp' => 'mp', '404' => '404'];
$lang['rating']                  = '评分';
?>