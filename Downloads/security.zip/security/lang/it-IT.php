<?php
/****************Plugin richiesto ***************/
$lang[$plugin.'name'] = 'Sicurezza';
$lang[$plugin.'version'] = '1.0.1';
$lang[$plugin.'update'] = '2025-02-09';
$lang[$plugin.'author'] = 'Gavin';
$lang[$plugin.'author_site'] = 'https://github.com/XHiddenProjects/CyberWeb';
$lang[$plugin.'author_mail'] = 'xhiddenprojects@gmail.com';
/**************** Lingua inglese ***************/
$lang[$plugin.'description'] = 'Software di sicurezza ospitato da CyberWeb';
$lang[$plugin.'alert'] = 'Questo sito è protetto da <a target="_blank" href="https://github.com/XHiddenProjects/CyberWeb">CyberWeb</a>!';
?>