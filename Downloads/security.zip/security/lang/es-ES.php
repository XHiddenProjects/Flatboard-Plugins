<?php
/************* Se requiere complemento **************/
$lang[$plugin.'name'] = 'Seguridad';
$lang[$plugin.'version'] = '1.0.1';
$lang[$plugin.'update'] = '2025-02-09';
$lang[$plugin.'author'] = 'Gavin';
$lang[$plugin.'author_site'] = 'https://github.com/XHiddenProjects/CyberWeb';
$lang[$plugin.'author_mail'] = 'xhiddenprojects@gmail.com';
/*************** Idioma Inglés **************/
$lang[$plugin.'description'] = 'Software de seguridad alojado en CyberWeb';
$lang[$plugin.'alert'] = '¡Este sitio está protegido por <a target="_blank" href="https://github.com/XHiddenProjects/CyberWeb">CyberWeb</a>!';
?>