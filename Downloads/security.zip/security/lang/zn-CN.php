<?php
/************ 需要插件 **************/
$lang[$plugin.'name'] = '安全';
$lang[$plugin.'版本'] = '1.0.3';
$lang[$plugin.'update'] = '2025-02-09';
$lang[$plugin.'author'] = '加文';
$lang[$plugin.'author_site'] = 'https://github.com/XHiddenProjects/Cyber​​Web';
$lang[$plugin.'author_mail'] = 'xhiddenprojects@gmail.com';
/************* 语言 英语 *************/
$lang[$plugin.'description'] = 'Cyber​​Web 托管的安全软件';
$lang[$plugin.'alert'] = '本网站受 <a target="_blank" href="https://github.com/XHiddenProjects/Cyber​​Web">Cyber​​Web</a> 保护！';
?>