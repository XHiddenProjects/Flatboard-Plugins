<?php
/************* Plugin requis **************/
$lang[$plugin.'name'] = 'Sécurité';
$lang[$plugin.'version'] = '1.0.1';
$lang[$plugin.'update'] = '09/02/2025';
$lang[$plugin.'author'] = 'Gavin';
$lang[$plugin.'author_site'] = 'https://github.com/XHiddenProjects/CyberWeb';
$lang[$plugin.'author_mail'] = 'xhiddenprojects@gmail.com';
/************* Langue Anglais **************/
$lang[$plugin.'description'] = 'Logiciel de sécurité hébergé par CyberWeb';
$lang[$plugin.'alert'] = 'Ce site est protégé par <a target="_blank" href="https://github.com/XHiddenProjects/CyberWeb">CyberWeb</a> !';
?>