<?php
/************* Plugin erforderlich ***************/
$lang[$plugin.'name'] = 'Sicherheit';
$lang[$plugin.'version'] = '1.0.3';
$lang[$plugin.'update'] = '2025-02-09';
$lang[$plugin.'author'] = 'Gavin';
$lang[$plugin.'author_site'] = 'https://github.com/XHiddenProjects/CyberWeb';
$lang[$plugin.'author_mail'] = 'xhiddenprojects@gmail.com';
/************* Sprache Englisch ***************/
$lang[$plugin.'description'] = 'Sicherheitssoftware, die von CyberWeb gehostet wird';
$lang[$plugin.'alert'] = 'Diese Site ist durch <a target="_blank" href="https://github.com/XHiddenProjects/CyberWeb">CyberWeb</a> geschützt!';
?>