<?php
/************* Plugin Required ***************/
$lang[$plugin.'name']            = 'Security';
$lang[$plugin.'version']         = '1.0.1';
$lang[$plugin.'update']          = '2025-02-09';
$lang[$plugin.'author']          = 'Gavin';
$lang[$plugin.'author_site']     = 'https://github.com/XHiddenProjects/CyberWeb';
$lang[$plugin.'author_mail']     = 'xhiddenprojects@gmail.com';
/************* Langue English ***************/
$lang[$plugin.'description']     = 'Security software that`s hosted by CyberWeb';
$lang[$plugin.'alert']           = 'This site is protected by <a target="_blank" href="https://github.com/XHiddenProjects/CyberWeb">CyberWeb</a>!';
?>