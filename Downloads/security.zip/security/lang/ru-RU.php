<?php
/************* Требуется плагин ***************/
$lang[$plugin.'name'] = 'Безопасность';
$lang[$plugin.'version'] = '1.0.1';
$lang[$plugin.'update'] = '2025-02-09';
$lang[$plugin.'author'] = 'Гэвин';
$lang[$plugin.'author_site'] = 'https://github.com/XHiddenProjects/CyberWeb';
$lang[$plugin.'author_mail'] = 'xhiddenprojects@gmail.com';
/************* Язык английский ****************/
$lang[$plugin.'description'] = 'Программное обеспечение безопасности, размещенное на CyberWeb';
$lang[$plugin.'alert'] = 'Этот сайт защищен <a target="_blank" href="https://github.com/XHiddenProjects/CyberWeb">CyberWeb</a>!';
?>