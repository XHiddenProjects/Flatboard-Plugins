<?php
/************* Plugin-Info ERFORDERLICH! ***************/
$lang[$plugin.'name']           = 'Spracheingabe';
$lang[$plugin.'version']        = '2.0.0';
$lang[$plugin.'update']         = '2023-06-04';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Sprache  ***************/
$lang[$plugin.'description']    = 'Einfache Möglichkeit, Ihre Nachricht mithilfe spezifischer Sprachbefehle zu schreiben.';
?>