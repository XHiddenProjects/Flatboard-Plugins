<?php
/************* Informations sur le plugin OBLIGATOIRES! ***************/
$lang[$plugin.'name']           = 'Saisie vocale';
$lang[$plugin.'version']        = '2.0.0';
$lang[$plugin.'update']         = '2023-06-04';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Langue  ***************/
$lang[$plugin.'description']    = 'Un moyen facile d`écrire votre message, en utilisant des commandes vocales spécifiques.';
?>