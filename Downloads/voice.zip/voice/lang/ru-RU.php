<?php
/************* Информация о плагине ТРЕБУЕТСЯ! ***************/
$lang[$plugin.'name']           = 'Голосовой ввод';
$lang[$plugin.'version']        = '2.0.0';
$lang[$plugin.'update']         = '2023-06-04';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Язык  ***************/
$lang[$plugin.'description']    = 'Простой способ написать сообщение, используя специальные голосовые команды.';
?>