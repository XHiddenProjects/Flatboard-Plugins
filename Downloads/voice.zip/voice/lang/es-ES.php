<?php
/************* Información del complemento REQUERIDO! ***************/
$lang[$plugin.'name']           = 'Escritura de voz';
$lang[$plugin.'version']        = '2.0.0';
$lang[$plugin.'update']         = '2023-06-04';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Idioma  ***************/
$lang[$plugin.'description']    = 'Manera fácil de escribir su mensaje, usando comandos de voz específicos.';
?>