<?php
/************* Informazioni sul plugin OBBLIGATORIE! ***************/
$lang[$plugin.'name']           = 'Digitazione vocale';
$lang[$plugin.'version']        = '2.0.0';
$lang[$plugin.'update']         = '2023-06-04';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/xhiddenprojects1/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Lingua  ***************/
$lang[$plugin.'description']    = 'Un modo semplice per scrivere il tuo messaggio, utilizzando specifici comandi vocali.';
?>