<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'VPN detector';
$lang[$plugin.'version']        = '2.0.1';
$lang[$plugin.'update']         = '2022-04-03';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Disallow users to access the forum with a hidden proxy, this is using vpnapi.io API';
$lang['vpnapi']                 = 'Enter your <a href="https://vpnapi.io/signup" target="_blank">vpnapi.io</a> API';
$lang['vpnalert']               = 'Expired alert?';
?>