<?php
/************* Plugin Info REQUIRED! ***************/
$lang[$plugin.'name']           = 'VPN detector';
$lang[$plugin.'version']        = '2.0.3';
$lang[$plugin.'update']         = '2022-04-10';
$lang[$plugin.'author']         = 'SurveyBuilder-Admin';
$lang[$plugin.'author_site']    = 'https://github.com/surveybuilderteams/Flatboard-Plugins';
$lang[$plugin.'author_mail']    = 'surveybuildersbot@gmail.com';
/************* Language  ***************/
$lang[$plugin.'description']    = 'Interdire aux utilisateurs d\'accéder au forum avec un proxy caché, cela utilise vpnapi.io AP';
$lang['vpnapi']                 = 'Saisissez votre API <a href="https://vpnapi.io/signup" target="_blank">vpnapi.io</a>';
$lang['vpnalert']               = 'Alerte expirée ?';
?>