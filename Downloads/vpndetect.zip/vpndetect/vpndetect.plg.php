<?php defined('FLATBOARD_PRO') or die('Flatboard community');
function vpndetect_install()
{
	global $lang;
	$plugin = 'vpndetect';
	if (flatDB::isValidEntry('plugin', $plugin))
		return;

    $data[$plugin.'state']   	  	= true; 
    $data['vpnapi']   	       	    = ''; 
    $data['vpnalert']   	       	= ''; 
	flatDB::saveEntry('plugin', $plugin, $data);
}
function vpndetect_config(){
        global $lang, $token;
	$plugin = 'vpndetect';
    $out = '';
 if(User::isAdmin()){
        if(!empty($_POST) && CSRF::check($token)){
             $data[$plugin.'state']= Util::isPOST('state') ? $_POST['state'] : ''; 
            $data['vpnapi']        = HTMLForm::clean($_POST['vpnapi']);
             $data['vpnalert']= Util::isPOST('vpnalert') ? $_POST['vpnalert'] : ''; 
             flatDB::saveEntry('plugin', $plugin, $data);
               $out .= Plugin::redirectMsg($lang['data_save'],'config.php' . DS . 'plugin' . DS . $plugin, $lang['plugin'].'&nbsp;<b>' .$lang[$plugin.'name']. '</b>');
            }else{
                 if (flatDB::isValidEntry('plugin', $plugin))
               $data = flatDB::readEntry('plugin', $plugin);
                $out .= HTMLForm::form('config.php' . DS . 'plugin' . DS . $plugin, '
                <div class="row">
                <div class="col">
                '.HTMLForm::checkBox('state', $data[$plugin.'state']).'
                </div>
                <div class="col">
                '.HTMLForm::checkBox('vpnalert', $data['vpnalert']).'
                </div>
                </div>
                 <div class="row">
                <div class="col">
                '.HTMLForm::text('vpnapi', $data['vpnapi']).'
                </div>
                </div>
                '.HTMLForm::simple_submit());
            }
return $out;
    }
}

function vpndetectalert(){
    global $lang;
	$plugin = 'vpndetect';
    $out = '';
      if (flatDB::isValidEntry('plugin', $plugin))
         $data = flatDB::readEntry('plugin', $plugin);
        if($data[$plugin.'state']){
            # vpnapi.io api
            $vpnData = @file_get_contents('https://vpnapi.io/api/'.User::getRealIpAddr().'?key='.$data['vpnapi']) ? file_get_contents('https://vpnapi.io/api/'.User::getRealIpAddr().'?key='.$data['vpnapi']) : false;
           $vpnCheck = @json_decode($vpnData, true) && json_decode($vpnData, true)['message']!=='' ? json_decode($vpnData, true) : 'api failed to connect';
              if(!$vpnData){
                  $out .= $data['vpnalert'] ? '<p class="fixed-top mt-5"><a href="https://vpnapi.io/pricing">vpnapi.io API</a> has <b>expired for the rest of the day</b> you can click the link to upgrade your account or just wait until tomorrow!</p>' : '';
              }else{
if($vpnCheck['security']['vpn'] && !User::isAdmin() || !User::isWorker()){
                    $out .= '<div class="bg-danger w-100 h-100 fixed-top vpndetectalertbox" style="z-index:500;">
                    <h1 class="text-center mt-5" style="font-size:52px;">Sorry You vpn is activated you can\'t use the server.</h1>
                    User Status:
                  <br/>
                 <center> 
                 <h3>IP:</h3><br/>
                    IP: '.$vpnCheck['ip'].'
                <h3>Secerity:</h3><br/>
                    VPN: '.$vpnCheck['security']['vpn'].'<br/>
                    Proxy: '.$vpnCheck['security']['proxy'].'<br/>
                    Tor: '.$vpnCheck['security']['tor'].'<br/><br/>
                    Relay: '.$vpnCheck['security']['relay'].'<br/>
                    <h3>Location:</h3>
                    City: '.$vpnCheck['location']['city'].'<br/>
                    Region: '.$vpnCheck['location']['region'].'<br/>
                    Country: '.$vpnCheck['location']['country'].'<br/>
                    Continent: '.$vpnCheck['location']['continent'].'<br/>
                    Region code: '.$vpnCheck['location']['region_code'].'<br/>
                    Country code: '.$vpnCheck['location']['country_code'].'<br/>
                    Continent code: '.$vpnCheck['location']['continent_code'].'<br/>
                    Latitude: '.$vpnCheck['location']['latitude'].'<br/>
                    Longitude: '.$vpnCheck['location']['longitude'].'<br/>
                    Time Zone: '.$vpnCheck['location']['time_zone'].'<br/>
                    Locale code: '.$vpnCheck['location']['locale_code'].'<br/>
                    Metro code: '.$vpnCheck['location']['metro_code'].'<br/>
                    European union?: '.$vpnCheck['location']['is_in_european_union'].'<br/>
                    <h3>Network:</h3><br/>
                    Network: '.$vpnCheck['network']['network'].'<br/>
                    Autonomous System Number(ASN): '.$vpnCheck['network']['autonomous_system_number'].'<br/>
                    Autonomous System Organization(ASO): '.$vpnCheck['network']['autonomous_system_organization'].'
                    </center>
                    <br/>
                    <center><img alt="VPN_Detect_plugin_icon" titlt="VPN Detect plugin icon" class="img-fluid rounded" width="320" height="320" src="'.HTML_PLUGIN_DIR.$plugin.DS.'icon.png"/></center>
                    </div>
                   ';
               }
              }
               
               echo $out;
        }
          
}
vpndetectalert();
?>